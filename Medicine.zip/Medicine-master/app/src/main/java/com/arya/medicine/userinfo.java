package com.arya.medicine;

public class userinfo {
    public String name;
    public String number;
    public  String city;
    public String state;
    public  String address;

    public userinfo(){

    }
    public userinfo(String name,String number,String city,String state, String address){
        this.name=name;
        this.number=number;
        this.city= city;
        this.state=state;
        this.address=address;
    }
}
